
# ShowDeathCause

This mod lets you know how you and your friends' miserable lives ended.

## What does it do?

The death notice is now accompanied by a message letting everyone know what killed you and how.


![img1](https://i.imgur.com/Xb2JU01.jpg)

## Installation

- Install [BepInEx Mod Pack](https://thunderstore.io/package/bbepis/BepInExPack/)
- Place the mod in the Risk of Rain 2\BepInEx\plugins folder.

## Co-Author
[MagnusMagnuson](https://thunderstore.io/package/MagnusMagnuson/)
