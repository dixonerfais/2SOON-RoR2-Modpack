# Risk Of Rain 2 Skill Swapper
Ever want to play the Artificer or Engineer with a movement skill, or ever want to play Mercenary with only Eviscerate? Now you can!
Swap out survivor's skills. Works in multiplayer (~~host only~~ works for everyone again).

Now with mid-run swapping!

Change log available [here](https://github.com/twofacejester/RoR2SkillSwapper/releases)

# Installation
1. Install [BenInEx](https://thunderstore.io/package/bbepis/BepInExPack/)
2. Download the latest [release](https://github.com/twofacejester/RoR2SkillSwapper/releases)
3. Extract the zip, and copy the skill-swapper folder to your BepInEx/plugins folder

# Usage
* Full usage guide can be found [here](https://github.com/twofacejester/RoR2SkillSwapper/wiki/Usage)

# Multiplayer
~~As of this time, skill swapping is only supported for the host.~~ Works in multiplayer for both host and client. The host does not require the mod in order to work on clients