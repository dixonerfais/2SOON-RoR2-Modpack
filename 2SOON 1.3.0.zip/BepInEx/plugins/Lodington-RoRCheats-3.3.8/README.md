# Lod's Cheat Codes

This Cheat menu is for having some fun in game by breaking the game or testing out items etc...!
Please note : Some function will not work if you are not host. 

## IMPORTANT NOTE : Please Check the dependency list, HjUpdater is required for this mod to work!!

# The Features

  - God Mode (togglable)
  - Infinite Skills (togglable)
  - Interactables ESP -> This will draw anything everything on screen that the player can interact with
  - Teleporter Menu -> This menu will let you edit anything that would involve the teleporter.
	- Skip Stage -> Skips Current Stage
	- Spawn Gold Portal
	- Spawn Blue Portal
	- Spawn Celestal Portal					
	- Spawn All Portals 
	- Insta Charge Teleporter -> If activated before the boss spawns no boss will spawn and the teleporter timer will be complete
	- +1 Mountain Shrine Stack -> Will Display how many mountains are activated on the button its self
  - Lobby Management -> Menu to kick / edit players 
  - Player Modifcations
	  - Give Money -> Gives the local player Money, incrementable by 100
	  - Give Lunar Coins -> Gives the local player Lunar Coins, incrementable by 10
	  - Give Experience -> Give the local player Experience, incrementable 100
	  
	  - Damage Lvl -> Will modify your characters damage per level basic on the number displayed (will update when added or subtracted)
	  - Crit Lvl -> Will modify your characters crit per level basic on the number displayed (will update when added or subtracted)
	  - Attack Speed -> Changes the rate of attack , incrementable 1 max is 3
	  - Armor -> Sets players armor value, incrementable 10
	  - Move Speed -> Sets Player Movement speed, incrementable 10 
	  - Character Selection -> Change Character in game to playable or non playable character.
	  
	- Stats Menu -> Will display current stats of the player
		- Damage
		- Crit
		- Attack Speed
		- Armor
		- Regen
		- Move Speed
		- Jump Count
		- Experience
		- Kills
	  - Always Sprint
	  - Aim Bot
	  - Unlock All -> Unlocks all items , skills , characters, and Skins
  - Item Management Menu
	- Roll Items -> Give the Player Random items
	- Give All Items
	- Drop Items For others -> lets you drop items from your inventory for others to pick up
	- Item Spawn Menu -> Will pop open a list of all the items in the game can be spawned in on the players location
	- Equipment Menu
	- Stack Inventory
	- Clear Inventory 
  - Noclip -> Allows Player to fly 


# dependencies

The Current Plugin(s) that are required to run this:

| Plugin | Package Name |
| ------ | ------ |
| R2API | [package/tristanmcpherson/R2API/] |
| BepInExPack | [bbepis-BepInExPack-3.0.0] |
| HjUpdaterAPI | [Lodington-HjUpdaterAPI-1.3.0] |

# Controls 
- Insert -> Opens the Menu
- V -> Adds Money
- B -> Opens teleporter Menu
- C -> Toggles Noclip

Note: In order to interact with the Menu press and hold tab to bring up the cursor. To set up keybinds please make sure there are no spaces.

# TODO

- Spawn boss
- Spawn more Enemies
- Add More Functionality to the "Lobby Managment Menu"

# Credits

DebugToolkit for GetNetworkUserFromString
iDeathHD for Noclip

# Changelog
- 3.3.8 
	- fixed bug when clicking on items with drop items off would display message
- 3.3.7 
	- updated Dependacys 

- 3.3.6
	- Fixed bugs
	- Keybinds no longer work in menu
	- added respawn button when local player dies
- 3.3.5
	- Made toggle for removing items actually work
	- Added +1 Shrine of the mountain button
	- updated obsolete code
- 3.3.4 
	- Added Toggle for removing items
	- fixed visual bugs with menu
	- fixed condense menu text in config file
	- Preped for 4.0.0 release
- 3.3.3 
	- Updated Bepin dependacy attributes 
- 3.3.2
	- Updated Menu so every open menu will close at title screen
	- Fixed Damage per lvl setting it self to random numbers
- 3.3.1 
	- Fixed Stats Menu not Appearing on screen
	- Added auto update library

- 3.3.0
	- Added Aim Bot
	- Added the ablity to drop Items by clicking them on top
	- Added Always Sprint
	- Added New Item Managment tab
	- Reorginzed menu(s)

- 3.2.3
	- Added a new Config variable to condense the menu for smaller resolutions.
	- Added Credits for no clip - Thanks iDeathHD 
- 3.2.2
	- Updated References for Hidden Realms Update
	
- 3.2.1 
	- Minor Bug Fixes with null point exceptions at main menu and when changing stages
	- Some Code Optimization

- 3.2.0 
	- Added Equipment Menu
	- Added new config varible to disable or enable unlock all button in player modification 
	- Added Advanced Tooltips for all items
	- Rearranged Menu buttons / windows

  
