# Twenty Minute Pings

Pings stay up for 20 minutes (configurable).

## Config

Change how long the pings stay up for in the config file.

## Known Issues

None so far. But if you find any, create a new issue on the github:
https://github.com/tvegh/TwentyMinutePings/issues

## Changelog

- 1.0.0: First version. I'm sure there will be no others, because my code is always flawless.
