You come home, friday night, and boot up discord. First thing you see is all four of your friends playing Risk of Rain 2 together, and all you want is to one day be able to join them.  
You're well aware that the lobbies are limited to 4 players, they told you when you asked if you could join.

**Congratulations. This mod is for you.**

Link it to your friends and you can all play together, no more simple excuses.

----

If you have a reason to, you can change the lobby size in BepInEx's config folder, under `dev.wildbook.toomanyfriends`.  
Default is 16 players.

----
**Changenotes**

v1.0.0

  - Initial release

----

Credit for this mod's icon goes entirely to [Sipondo](https://thunderstore.io/package/Sipondo/), check out their mods as well.