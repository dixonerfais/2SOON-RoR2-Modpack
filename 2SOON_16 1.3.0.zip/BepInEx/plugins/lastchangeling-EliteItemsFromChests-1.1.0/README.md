## About

Adds Ifrit's Distinction, Silence Between Two Strikes, Her Biting Embrace, N'kuhana's Retort, and Spectral Circlet to the equipment drop table so they can be drops from equipment chests and shrines.
Note that Spectral Circlet doesn't have an equipment model or icon in game so don't be alarmed by the white square.

## Installation

Place the EliteItemsFromChests.dll into the bbepis plugins folder.