# Mobile Turret Fungus
#### By bongopd

A mod that makes the bustling fungus always active on engineer turrets, even when moving. This is so that the walking turrets are no longer worthless garbage.

**What the mod does:**

-Makes the bustling fungus always active on engineer turrets, even when moving.

### Installation Guide

- Copy `MobileTurretFungus.dll` to your BepInEx plugins folder.

### Changelog

`0.0.1` - Initial release of the mod.