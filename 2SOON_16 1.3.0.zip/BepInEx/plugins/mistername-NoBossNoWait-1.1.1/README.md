## NoBossNoWait

  - Makes the teleporter charge when every boss is killed
  - Supports [HjUpdaterAPI](https://thunderstore.io/package/Lodington/HjUpdaterAPI/) as soft dependency for auto updating 
  
### updates
- 1.0.0
    release
- 1.1.0 fixed for limbo and added support for HjUpdaterAPI
# Installation
Drop NoBossNoWait.dll into `\BepInEx\plugins\`