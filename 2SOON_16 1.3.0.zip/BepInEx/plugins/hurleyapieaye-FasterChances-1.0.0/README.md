# FasterChances
---

No more waiting 2 seconds in between Shrine of Chance uses! Completely eliminates the time you have to wait in between each use. Works very nicely with the InfiniteChance mod.


---

## Installation

- Download and install the latest version of BepInEx.
- Copy the FasterChances.dll file into your plugins folder.

---

## Credits

A very simple mod by Hurley & Zyph for Risk of Rain 2!