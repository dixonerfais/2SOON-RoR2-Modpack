﻿You do **not** need the dependency if you have R2API installed.
_If there was a way to make an "Either of these mods" dependency, I would._

Makes the rusted lockbox spawned from rusted keys increase in size as you acquire more keys.

There's default values set, but you can configure to scale it differently faster, or even to apply the scaling to the first lockbox.

If you just want to make the lockboxes bigger in general and don't want any fancy scaling, you can configure that too!

###Installation: 
Place in your Bepinex/Plugins folder.
If you have the seperate MMHook

##Changelog:
- 1.1.2 and 1.1.3 Now baited, hooked and R2API'd.
- 1.1.1 Now baited.
- 1.1.0 Now with the possibility of constant scaling.
- 1.0.0 Release!