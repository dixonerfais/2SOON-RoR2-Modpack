# Lod's Cheat Codes

This Cheat menu is for having some fun in game by breaking the game or testing out items etc...!
Please note : Some function will not work if you are not host. 

# The Features

  - God Mode (togglable)
  - Infinite Skills (togglable)
  - Interactables ESP -> This will draw anything everything on screen that the player can interact with
  - Character Selection -> Change Character in game to playable or non playable character.
  - Stats Menu -> Will display current stats of the player
	- Damage
	- Crit
	- Attack Speed
	- Armor
	- Regen
	- Move Speed
	- Jump Count
	- Experience
	- Kills
  - Item Spawn Menu -> Will pop open a list of all the items in the game can be spawned in on the players location
  - Teleporter Menu -> This menu will let you edit anything that would involve the teleporter.
	- Skip Stage -> Skips Current Stage
	- Spawn Gold Portal
	- Spawn Blue Portal
	- Spawn Celestal Portal					
	- Spawn All Portals 
	- Insta Charge Teleporter -> If activated before the boss spawns no boss will spawn and the teleporter timer will be complete
  - Lobby Management -> Menu to kick / edit players 
  - Player Modifcations
	  - Give Money -> Gives the local player Money, incrementable by 100
	  - Give Lunar Coins -> Gives the local player Lunar Coins, incrementable by 10
	  - Give Experience -> Give the local player Experience, incrementable 100
	  - Roll Items -> Give the Player Random items
	  - Damage Lvl -> Will modify your characters damage per level basic on the number displayed (will update when added or subtracted)
	  - Crit Lvl -> Will modify your characters crit per level basic on the number displayed (will update when added or subtracted)
	  - Attack Speed -> Changes the rate of attack , incrementable 1 max is 3
	  - Armor -> Sets players armor value, incrementable 10
	  - Move Speed -> Sets Player Movement speed, incrementable 10 
	  - Unlock All -> Unlocks all items , skills , characters, and Skins
  - Noclip -> Allows Player to fly 


# dependencies

The Current Plugin(s) that are required to run this:

| Plugin | Package Name |
| ------ | ------ |
| R2API | [package/tristanmcpherson/R2API/][PlDb] |
| BepInExPack | [bbepis-BepInExPack-3.0.0][PlDb] |

# Controls 
- Insert -> Opens the Menu
- V -> Adds Money
- B -> Opens teleporter Menu
- C -> Toggles Noclip

Note: In order to interact with the Menu press and hold tab to bring up the cursor. To set up keybinds please make sure there are no spaces.

# TODO

- Add Equipment Spawner [DONE]
- Massive Damage  [Planned for 3.3.0]
- Spawn boss
- Spawn Chest / prefab like mountain shrine  [Planned for 3.3.0]
- Stack Items  [Planned for 3.3.0]
- Spawn more Enemies
- Add More Functionality to the "Lobby Managment Menu"

# Credits

DebugToolkit for GetNetworkUserFromString

# Changelog
- 3.2.1 
	- Minor Bug Fixes with null point exceptions at main menu and when changing stages
	- Some Code Optimization

- 3.2.0 
	- Added Equipment Menu
	- Added new config varible to disable or enable unlock all button in player modification 
	- Added Advanced Tooltips for all items
	- Rearranged Menu buttons / windows
	

- 3.1.0
	- Corrected Dependencies in read me
	- Updated Main menu buttons
	- Added Player Modifcations tab
	- Added more stat modifers in player modifcations tab
	- Added Unlock All button 
	- Updated stats display
	- Rearranged menus "start positions"

- 3.0.1 
	- Removed Debuging Logs

- 3.0.0
	- Updated Character Selection so players dont have to restart the game to access the menu again
	- Updated GUI skin for item spawn menu
	- Updated GUI skin for Character selection menu
	- Updated Noclip
	- Added "insta Teleporter Charage" to the teleporter menu
	- Added "Give all items" Button 
	- Updated ESP performance 
	- Added Teleport to ESP List
	- Fixed bug with stat menu opening with main menu by default

- 2.4.4
	- Updated GUID because of conflict with RoR2Cheats
	
- 2.4.3
	- Added Lobby Management menu
	- Added Kicking to lobby Management menu
	- Moved Skip Stage Button to the teleporter menu
	- Fixed Nullpointexception when having damage / crit modifiers on when in game menu.
	- Removed Distance from intercation ESP to improve performance

- 2.4.2
	- Added Keybind Config
	- Fixed Stat Menu Opening by default (found by wizard lizard #4758)
	- Minor Code fixes

- 2.4.1 
	- Acually upadated this time :D

- 2.4.0
	- Added Teleporter menu
	- Added x10 button in items menu
	- Added Noclip (needs work :D)
	- Added Dragable windows (click and hold on blue square)
	
Note: Changeable keybinds coming soon!

- 2.3.2
	- Textured Item Spawn menu
	- Removed Default Mouse 4 keybind to open menu and added a toggle for it
	- Fixed Typo in README

- 2.3.1
	- Added Character Selection
	- Added a way to skip stages
	- Added "Spawn All portals"
	- Reordered Menu


  
