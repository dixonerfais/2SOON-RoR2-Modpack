## NoBossNoWait

  - Makes the teleporter charge when every boss is killed
  
# Installation
Drop NoBossNoWait.dll into `\BepInEx\plugins\`