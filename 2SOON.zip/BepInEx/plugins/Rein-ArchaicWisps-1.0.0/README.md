﻿This mod adds Archaic Wisps (and totally nothing else, I promise) to the game. They will spawn after the first loop and are effectively Greater Wisps that go to the gym.

If you have any issues contact me on the modding (or the offical) discord. (@Rein#7551) You can also visit the github link above and create issues if that tickles your fancy.


Also has lots of comments in the source to show how to use directorcardlib.


## Changelog
### 1.0.0
- First release
