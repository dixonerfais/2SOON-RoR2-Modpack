#What does this mod do?
It allows the Grovetender to spawn on any map, that's literally all it does.
Install by dropping ``Grovetender.dll`` into your plugins folder.