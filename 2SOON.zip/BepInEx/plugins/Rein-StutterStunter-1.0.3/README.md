## __This Mod should not be used with under 8gb of RAM__

This isn't a suggestion, or joke. Don't do it. If you want to understand why, read on below.

## What it does
This mod addresses the stuttering that the game experiences periodically. Not everyone gets the stutters, but they tend to be made worse by the presence of mods.

With this mod installed you should be getting absolutely no stuttering outside of situations where your CPU/GPU are at maximum load.

Below I will explain how this all works for anyone interested.

## What are the stutters?
A stutter is one (or more) lost frames that occur at somewhat regular intervals. Different computers will get the issue at different rates and severities.

I personally get them as a burst of 5-6 frames every 8 or so seconds. Other people report 1-2 frames every 8 seconds.

Regardless, if you get them they are quite irritating and distracting.

## What causes the stutters?
Stutters are caused by something called garbage collection. Some brief history:

In the olden days programmers would allocate ram to store a value, and that ram would stay allocated until they released it. 
This meant that if someone was doing things poorly, it was possible to a memory leak, where more and more memory is reserved and never released until the system ran out of ram.

Obviously, that was a problem. Pretty quickly people put together languages that would automatically detect when memory wasn't in use and release it.
The process of going through all the reserved memory and releasing what isn't needed is called garbage collection.

Here is the catch, garbage collection is not fast. There can be a lot of things to sort through, and the process of deciding what should be released and what should not isn't simple.

## How does this mod fix the issue?

Garbage collection is a very necessecary step, and simply skipping it would be an awful idea. At the same time, garbage collection is the root cause of stuttering, and there isn't much we can do to make the game not stutter when garbage is collected.

However, the stutter is only really an issue if it happens while we are playing. If it occured during load screens, and while the game is paused then it would barely be noticeable.

That is what this mod does. While you are in a stage it tells the game to stop collecting garbage, and while a new stage is loading it allows the game to collect.

However, this means that while you are playing the game is actually leaking memory. On paper, it might be possible to use up enough memory between stages for problems to arise.

In practice though, the amount of memory leaked is tiny, and considering we rarely spend more than 15 minutes on a single stage the odds of running out of ram are quite low.

That isn't enough though. In addition to performing garbage collection when stages are loading, this mod also performs it while the pause menu is open.
In addition, the mod also tracks memory usage and will notify you in chat if it passes a warning threshold. If it passes a cap, it will notify you again and eventually force a garbage collection during gameplay.

As of right now the thresholds are not configurable, due to the potential for things to go wrong if bad values are entered.

## Other uses for this mod

Every 10 seconds, memory usage is logged to a csv (readable in excel/sheets, or even notepad) along with a timestamp (Time.fixedUnscaledTime). 
This means, if you log what your mod is doing at all times with the same timestamp, you can get an idea of what is creating garbage.

# Changelog

### 1.0.3
- 10/10 update compatiblity.

### 1.0.2
- This totally existed

### 1.0.1
- Added config option for logging

### 1.0.0
- Release