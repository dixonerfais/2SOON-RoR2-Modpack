# Lod's Cheat Codes

This Cheat menu is for having some fun in game by breaking the game or testing out items etc...!

# The Features

  - God Mode (togglable)
  - Infinite Skills (togglable)
  - Interactables ESP -> This will draw anything everything on screen that the player can interact with
  - Character Selection -> Changed Character once
  - Stats Menu -> Will display current stats of the player
  - Item Spawn Menu -> Will pop open a list of all the items in the game can be spawned in on the players location
  - Teleporter Menu -> Will spawn all the orbs (Gold, Newt, and celestial) before the teleportor starts 
  - Noclip -> Allows Player to fly (needs work)
  - Mouse 4 button toggle -> Will enable mouse 4 to be used to open the menu
  - Give Money -> Gives the local player Money, incrementable by 100
  - Give Lunar Coins -> Gives the local player Lunar Coins, incrementable by 10
  - Give Experience -> Give the local player Experience, incrementable 100
  - Roll Items -> Give the Player Random items
  - Damage Lvl -> Will modify your characters damage per level basic on the number displayed (will update when added or subtracted)
  - Crit Lvl -> Will modify your characters crit per level basic on the number displayed (will update when added or subtracted)
  - Skip Stage -> will skip the stage you are currently on



# dependencies

The Current Plugin(s) that are required to run this:

| Plugin | Package Name |
| ------ | ------ |
| R2API | [package/tristanmcpherson/R2API/][PlDb] |

# Controls 
- Insert -> Opens the Menu
- V -> Adds Money

Note: In order to interact with the Menu press and hold tab to bring up the cursor.

# TODO

- Fix Main menu clipping
- Style Item menu [Done]
- Add Character Select [Done]
- Add Equipment Spawner
- Skip Stage [Done]
- Spawn all Portals [Done]
- Massive Damage 
- Spawn boss
- Spawn Chest / prefab like mountain shrine
- Stack Items 
- Give all items [Done]
- Spawn more Enemies

# Changelog

- 2.4.1 
	-Acually upadated this time :D

- 2.4.0
	- Added Teleporter menu
	- Added x10 button in items menu
	- Added Noclip (needs work :D)
	- Added Dragable windows (click and hold on blue square)
	
Note: Changeable keybinds coming soon!

- 2.3.2
	- Textured Item Spawn menu
	- Removed Default Mouse 4 keybind to open menu and added a toggle for it
	- Fixed Typo in README

- 2.3.1
	- Added Character Selection
	- Added a way to skip stages
	- Added "Spawn All portals"
	- Reordered Menu


  
