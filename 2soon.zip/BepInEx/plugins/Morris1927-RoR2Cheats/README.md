# RoR2Cheats
Adds various commands that are useful for debugging, or messing around.

# Commands
* To access the console press Ctrl+Alt+Tilde
* god
* kill_all
* fov [degrees]
* seed [newSeed]
* no_enemies
* time_scale [timeMultipler]
* give_item [itemName/ID] [count] [playerName/playerID]
* give_equip [equipName/ID] [playerName/playerID]
* give_money [money] [playerName/playerID]
* give_exp [exp] [playerName/playerID]
* list_items
* list_equips
* next_round [sceneName]
* fixed_time [time]
* stage_clear_count [count]
* spawn_as [characterBody] [playerName/playerID]
* spawn_ai [characterMaster] [eliteIndex] [teamIndex] [braindead]
* spawn_body [characterBody]
* player_list
* true_kill [playerName/playerID]
* add_gold
* add_blue
* add_celestial
* change_team [teamIndex] [playerName/playerID]
* respawn [playerName/playerID]

# Installation
###  With BepInEx
 1. Extract "RoR2Cheats.dll" from the zip file and place it into  "/Risk of Rain 2/BepInEx/plugins/RoR2Cheats/" folder.
 2. Done
 
# Notes
### 2.3.1---
* Added 2 new commands ( Credits to popcron )
* Commands "list_items" and "list_equips" will now give a list of items and equipments respectively.
* Updated the body lists for spawn commands

### 2.3.0---
* Added 6 new commands ( Credits to Anticode )
* Spawn commands are no longer case-sensitive
* Added aliases to spawn commands. eg. spawn_as MULT instead of Toolbot, or spawn_as Artificer instead of Mage
* Fixed a bug where BeetleQueens would not spawn properly

### 2.2.2---
* Spawn commands work slightly better

### 2.2.1---
* Updated to work with the newest build

### 2.2.0---
* Added give_money, give_exp.
* Changed spawnas to spawn_as, nextround to next_round and spawn_braindead to spawn_body
* time_scale now works in multiplayer
* Added addition arguments to give_item, give_equip, spawn_ai
* Overall you get yelled at less for inputting the wrong thing
* next_round now doesn't care which stage you are on and works quicker

### 2.1.0---
 * Added compatibility with other console mods. Credit to Wildbook, check out their mod [here](https://thunderstore.io/package/wildbook/Multitudes/)
 * Fixed no_enemies spawning enemies through stages/bosses