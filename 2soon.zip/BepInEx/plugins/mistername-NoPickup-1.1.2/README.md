# NoPickup
	- Disables autopickup of items
		- Only on items set to false in config (specific per character or all)
	- Requires host to have the mod

## Installation
Drop `NoPickup.dll` into `\BepInEx\plugins\`

## Changelog
	- v1.0.0
		- Release
	- v1.1.0
		- Config added	
	- v1.1.1
		- fixed config and made it clearer
	- v1.1.2
		- new ror2 update support
## ToDo
	- add in game config