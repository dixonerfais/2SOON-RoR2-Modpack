# EnemiesSpawnFaster

Risk of Rain 2 Mod to help the early game move along faster.

Cuts the average spawn time in half.
