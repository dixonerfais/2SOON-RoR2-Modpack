﻿### Kookeh's original DropItemMod ported to BepInEx and R2API!

Allows players to drop their own items out of their inventories to trade with friends / throw away items!
(For original host only functionality download a 1.x version)

### Requirements:

- \>= R2API 2.0.8
- \>= MiniRpcLib 0.0.1
- \>= BepInExPack 2.0.0

### Changelog:
- 1.x - Readme update
- 2.0.0 - Complete remake