A library to help mod developers with networking.  
Currently alpha/beta, but works just fine. Expect breaking changes.

If you're a mod user, just drop this in your plugins folder and you should be all set!