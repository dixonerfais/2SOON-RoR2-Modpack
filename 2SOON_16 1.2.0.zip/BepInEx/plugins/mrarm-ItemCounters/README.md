# Item Counters

![Image](https://i.imgur.com/fXAr1x0.png)

Have you ever felt like your friend has more items than you but couldn't find time to count how many items do you have exactly in order to prove that? Then this mod if for you - now you can check how many items of each tier each of you have!