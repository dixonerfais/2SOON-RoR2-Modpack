# DPSMeter
#### By iDeathHD

A mod that shows a dps meter on your screen.

### Informations

- You can change the x and y position of the interface in the config file, various other options are available in the config, check it.

- Only the host of the game will have the meter working in multiplayer. Having the dps meter works for others will require everyone to have the mod and minirpclib installed in a future update.

- If you find any bug / have feedback about the mod, tell me about it in the RoR2 Modding Discord. @iDeathHD

### Installation Guide

- Copy `DPSMeter` folder to your BepInEx plugins folder.

### Changelog

`0.0.5` - Updated for the Skills 2.0 Game Update.

`0.0.4` - Now support clients with MiniRpcLib.

`0.0.3` - Fixed ugly null exception in console.

`0.0.2` - Added support for custom timescale.

`0.0.1` - Initial release of the mod.