# Thiccify

Removes the skirt from artificer, and the scarf from huntress. makes both thiccer.

# ChangeLog 
	-Fixed Compatiablity with RoRCheats

  
