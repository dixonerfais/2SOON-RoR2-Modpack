﻿If you have any issues contact me on the modding (or the offical) discord. (@Rein#7551) You can also visit the github link above and create issues if that tickles your fancy.

Check the source to get an idea for how it works. For working sample code check the source for ArchaicWisps, another mod by me.

## Changelog
### 1.0.1
- Fixed readme typo... rip.
### 1.0.0
- First release
